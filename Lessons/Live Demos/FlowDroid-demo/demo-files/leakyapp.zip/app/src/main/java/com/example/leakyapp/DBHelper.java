package com.example.leakyapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    static final String TABLE_NAME = "my_table";
    static final String ID_COL = "id";
    static final String NAME_COL = "name";
    static final String DURATION_COL = "duration";
    static final String DESCRIPTION_COL = "description";
    static final String DB_NAME = "my_db";

    public DBHelper(Context context) {
        super(context, DB_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + NAME_COL + " TEXT,"
                + DESCRIPTION_COL + " TEXT)";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void addItem(String name, String description) {
        SQLiteDatabase db = getWritableDatabase();
        String query = "INSERT INTO " + TABLE_NAME +" (" + NAME_COL + "," + DESCRIPTION_COL + ")"
                + "VALUES (" + name + ", " + description +")";
        db.execSQL(query);
    }
}
