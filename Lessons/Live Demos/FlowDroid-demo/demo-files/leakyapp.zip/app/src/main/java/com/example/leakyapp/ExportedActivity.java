package com.example.leakyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

public class ExportedActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exported);
        Intent i = getIntent();
        try(DBHelper db = new DBHelper(this)) {
            String name = i.getStringExtra("name");
            String desc = i.getStringExtra("desc");
            db.addItem(name, desc);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}