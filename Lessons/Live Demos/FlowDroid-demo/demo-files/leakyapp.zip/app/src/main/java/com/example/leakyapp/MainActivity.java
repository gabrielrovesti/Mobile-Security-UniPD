package com.example.leakyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.TelephonyManager;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TelephonyManager tm = getSystemService(TelephonyManager.class);

        @SuppressLint("MissingPermission")
        String number = tm.getLine1Number();
        Intent i = new Intent("BROADCAST_NUMBER");

        i.putExtra("number", number);
        sendBroadcast(i);
    }
}